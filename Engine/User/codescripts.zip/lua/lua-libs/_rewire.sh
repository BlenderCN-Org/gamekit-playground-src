ln -s $GAMEKIT/Tools/Misc/lua-libs  
