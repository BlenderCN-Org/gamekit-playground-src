-- set the version

__VERSION = 1